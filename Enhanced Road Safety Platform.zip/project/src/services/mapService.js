import { useState, useEffect } from 'react';

const API_KEY = import.meta.env.VITE_MAPS_API_KEY || 'demo';

export async function getOptimalRoutes(origin, destination) {
  // Simulate API call for demo
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        routes: [
          {
            id: 1,
            path: generatePath(origin, destination),
            safetyScore: 95,
            duration: '15 mins',
            distance: '3.2 km',
            hazards: []
          }
        ],
        bounds: {
          north: 11.0368,
          south: 11.0168,
          east: 76.9658,
          west: 76.9458
        }
      });
    }, 1000);
  });
}

export async function getHazardData(bounds) {
  // Simulate hazard data
  return [
    {
      id: 1,
      type: 'accident',
      location: { lat: 11.0268, lng: 76.9558 },
      severity: 'medium',
      timestamp: new Date().toISOString()
    }
  ];
}

export async function getPredictiveInsights(routes) {
  // Simulate predictions
  return {
    congestionProbability: 0.3,
    weatherImpact: 'low',
    recommendedTimeWindows: ['10:00', '14:00', '16:00']
  };
}

function generatePath(origin, destination) {
  // Generate a mock path between points
  return [
    { lat: origin.lat, lng: origin.lng },
    { lat: origin.lat + 0.01, lng: origin.lng + 0.01 },
    { lat: destination.lat, lng: destination.lng }
  ];
}