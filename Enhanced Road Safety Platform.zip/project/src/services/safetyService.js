const API_BASE_URL = import.meta.env.VITE_API_BASE_URL;

export async function calculateSafeRoute(start, end) {
  try {
    const response = await fetch(`${API_BASE_URL}/routes/calculate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ start, end }),
    });

    if (!response.ok) {
      throw new Error('Failed to calculate route');
    }

    return await response.json();
  } catch (error) {
    console.error('Route calculation error:', error);
    throw error;
  }
}

export async function getHazardUpdates(bounds) {
  try {
    const response = await fetch(`${API_BASE_URL}/hazards`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bounds),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch hazard updates');
    }

    return await response.json();
  } catch (error) {
    console.error('Hazard update error:', error);
    throw error;
  }
}

export async function getSafetyScore(location) {
  try {
    const response = await fetch(`${API_BASE_URL}/safety-score`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ location }),
    });

    if (!response.ok) {
      throw new Error('Failed to fetch safety score');
    }

    return await response.json();
  } catch (error) {
    console.error('Safety score error:', error);
    throw error;
  }
}