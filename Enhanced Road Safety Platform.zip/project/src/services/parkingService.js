const MOCK_PARKING_DATA = [
  {
    id: 1,
    name: 'Central Parking',
    location: [11.0168, 76.9558],
    available: 45,
    total: 100,
    rate: 30
  },
  {
    id: 2,
    name: 'RS Puram Parking',
    location: [11.0268, 76.9658],
    available: 25,
    total: 75,
    rate: 25
  }
];

export async function getParkingStatus() {
  // Simulate API call
  return new Promise((resolve) => {
    setTimeout(() => resolve(MOCK_PARKING_DATA), 1000);
  });
}

export async function getParkingPredictions(facilityId) {
  // Simulate predictions
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve([
        { time: '1h', predicted: 40 },
        { time: '2h', predicted: 35 },
        { time: '3h', predicted: 50 }
      ]);
    }, 500);
  });
}