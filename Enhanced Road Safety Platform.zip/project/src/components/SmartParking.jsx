import { useState, useEffect } from 'react';
import { Card, Title, BarChart, DonutChart } from '@tremor/react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { useWebSocket } from '../contexts/WebSocketContext';

const COIMBATORE_CENTER = [11.0168, 76.9558];

function SmartParking() {
  const [parkingData, setParkingData] = useState([]);
  const [selectedFacility, setSelectedFacility] = useState(null);
  const [predictions, setPredictions] = useState(null);
  const { socket } = useWebSocket();

  useEffect(() => {
    // Subscribe to real-time parking updates
    socket.on('parking-update', (data) => {
      setParkingData(data);
    });

    // Get initial parking data
    fetch('/api/parking/status')
      .then(res => res.json())
      .then(data => setParkingData(data))
      .catch(err => console.error('Failed to fetch parking data:', err));

    return () => {
      socket.off('parking-update');
    };
  }, [socket]);

  useEffect(() => {
    if (selectedFacility) {
      fetch(`/api/parking/predictions/${selectedFacility.id}`)
        .then(res => res.json())
        .then(data => setPredictions(data))
        .catch(err => console.error('Failed to fetch predictions:', err));
    }
  }, [selectedFacility]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <Title>Parking Facilities Map</Title>
          <div className="h-[500px] mt-4 rounded-lg overflow-hidden">
            <MapContainer
              center={COIMBATORE_CENTER}
              zoom={13}
              className="h-full w-full"
            >
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              {parkingData.map(facility => (
                <Marker
                  key={facility.id}
                  position={facility.location}
                  eventHandlers={{
                    click: () => setSelectedFacility(facility)
                  }}
                >
                  <Popup>
                    <div className="p-2">
                      <h3 className="font-bold">{facility.name}</h3>
                      <p>Available: {facility.available}/{facility.total}</p>
                      <p>Rate: ₹{facility.rate}/hour</p>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </Card>

        <Card>
          <Title>Availability Overview</Title>
          <DonutChart
            className="mt-4 h-48"
            data={parkingData}
            category="available"
            index="name"
            valueFormatter={(value) => `${value} spots`}
            colors={['green', 'yellow', 'red']}
          />
        </Card>
      </div>

      {selectedFacility && (
        <Card>
          <Title>Facility Details: {selectedFacility.name}</Title>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
            <div>
              <h3 className="font-semibold mb-2">Current Status</h3>
              <div className="space-y-2">
                <p>Available Spots: {selectedFacility.available}</p>
                <p>Total Capacity: {selectedFacility.total}</p>
                <p>Current Rate: ₹{selectedFacility.rate}/hour</p>
                <div className="w-full bg-gray-200 rounded-full h-2.5">
                  <div
                    className="bg-blue-600 h-2.5 rounded-full"
                    style={{
                      width: `${(selectedFacility.available / selectedFacility.total) * 100}%`
                    }}
                  ></div>
                </div>
              </div>
            </div>

            {predictions && (
              <div>
                <h3 className="font-semibold mb-2">Predicted Availability</h3>
                <BarChart
                  className="h-48"
                  data={predictions}
                  index="time"
                  categories={['predicted']}
                  colors={['blue']}
                />
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
}

export default SmartParking;