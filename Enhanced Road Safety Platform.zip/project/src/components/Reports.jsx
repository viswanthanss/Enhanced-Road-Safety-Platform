import { useState } from 'react';
import { Card, Title, TextInput, Select, SelectItem, Button, Badge } from '@tremor/react';

const HAZARD_TYPES = [
  { value: 'accident', label: 'Accident' },
  { value: 'obstruction', label: 'Road Obstruction' },
  { value: 'damage', label: 'Infrastructure Damage' },
  { value: 'signal', label: 'Traffic Signal Issue' },
  { value: 'flooding', label: 'Flooding' }
];

const RECENT_REPORTS = [
  {
    id: 1,
    type: 'accident',
    location: 'Gandhipuram Signal',
    status: 'active',
    timestamp: '10 minutes ago',
    description: 'Minor collision between two vehicles'
  },
  {
    id: 2,
    type: 'damage',
    location: 'RS Puram Main Road',
    status: 'resolved',
    timestamp: '1 hour ago',
    description: 'Large pothole causing traffic slowdown'
  }
];

function Reports() {
  const [hazardType, setHazardType] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [image, setImage] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({ hazardType, location, description, image });
  };

  const getStatusColor = (status) => {
    return status === 'active' ? 'red' : 'green';
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>Report a Hazard</Title>
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            <div className="relative">
              <Select
                value={hazardType}
                onValueChange={setHazardType}
                placeholder="Select hazard type"
                className="input-clean"
              >
                {HAZARD_TYPES.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </Select>
            </div>

            <TextInput
              placeholder="Location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="input-clean"
            />

            <TextInput
              placeholder="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="input-clean"
            />

            <div className="space-y-2">
              <label className="block text-sm font-medium text-gray-700">
                Upload Image (optional)
              </label>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => setImage(e.target.files[0])}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-full file:border-0
                  file:text-sm file:font-semibold
                  file:bg-blue-50 file:text-blue-700
                  hover:file:bg-blue-100"
              />
            </div>

            <Button type="submit" className="w-full btn btn-primary">
              Submit Report
            </Button>
          </form>
        </Card>

        <Card>
          <Title>Recent Reports</Title>
          <div className="mt-4 space-y-4">
            {RECENT_REPORTS.map((report) => (
              <div
                key={report.id}
                className="p-4 bg-gray-50 rounded-lg space-y-2"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-semibold">{report.location}</p>
                    <p className="text-sm text-gray-600">{report.description}</p>
                  </div>
                  <Badge color={getStatusColor(report.status)}>
                    {report.status}
                  </Badge>
                </div>
                <div className="flex justify-between items-center text-sm text-gray-500">
                  <span>{HAZARD_TYPES.find(t => t.value === report.type)?.label}</span>
                  <span>{report.timestamp}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <Title>Report Statistics</Title>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-600">Total Reports Today</p>
            <p className="text-2xl font-semibold">24</p>
          </div>
          <div className="p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-600">Resolved Reports</p>
            <p className="text-2xl font-semibold">18</p>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg">
            <p className="text-sm text-gray-600">Average Response Time</p>
            <p className="text-2xl font-semibold">15 mins</p>
          </div>
        </div>
      </Card>
    </div>
  );
}

export default Reports;