import { Card, Title, AreaChart, BarChart, DonutChart } from '@tremor/react';

const ACCIDENT_DATA = [
  { date: '2024-01', accidents: 45, injuries: 32, fatalities: 2 },
  { date: '2024-02', accidents: 38, injuries: 28, fatalities: 1 },
  { date: '2024-03', accidents: 42, injuries: 30, fatalities: 2 }
];

const HOTSPOT_DATA = [
  { location: 'Gandhipuram', incidents: 15, risk: 'high' },
  { location: 'RS Puram', incidents: 12, risk: 'medium' },
  { location: 'Peelamedu', incidents: 18, risk: 'high' },
  { location: 'Singanallur', incidents: 8, risk: 'low' }
];

const TIME_DISTRIBUTION = [
  { time: '6 AM - 9 AM', accidents: 28 },
  { time: '9 AM - 12 PM', accidents: 35 },
  { time: '12 PM - 3 PM', accidents: 30 },
  { time: '3 PM - 6 PM', accidents: 42 },
  { time: '6 PM - 9 PM', accidents: 38 },
  { time: '9 PM - 12 AM', accidents: 25 }
];

function Analytics() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>Accident Trends (Last 3 Months)</Title>
          <AreaChart
            className="mt-4 h-72"
            data={ACCIDENT_DATA}
            index="date"
            categories={['accidents', 'injuries', 'fatalities']}
            colors={['blue', 'yellow', 'red']}
          />
        </Card>

        <Card>
          <Title>Accident Hotspots</Title>
          <BarChart
            className="mt-4 h-72"
            data={HOTSPOT_DATA}
            index="location"
            categories={['incidents']}
            colors={['red']}
          />
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <Title>Time Distribution</Title>
          <DonutChart
            className="mt-4 h-72"
            data={TIME_DISTRIBUTION}
            category="accidents"
            index="time"
            colors={['blue', 'cyan', 'indigo', 'violet', 'purple', 'fuchsia']}
          />
        </Card>

        <Card>
          <Title>Key Insights</Title>
          <div className="mt-4 space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="font-semibold">Peak Hours</p>
              <p className="text-sm text-gray-600">
                Highest accident rates observed between 3 PM - 6 PM
              </p>
            </div>
            <div className="p-4 bg-yellow-50 rounded-lg">
              <p className="font-semibold">High-Risk Areas</p>
              <p className="text-sm text-gray-600">
                Peelamedu shows highest incident rate, followed by Gandhipuram
              </p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="font-semibold">Improvement Trends</p>
              <p className="text-sm text-gray-600">
                15% reduction in accidents compared to previous quarter
              </p>
            </div>
          </div>
        </Card>

        <Card>
          <Title>Recommendations</Title>
          <div className="mt-4 space-y-4">
            <div className="p-4 border border-blue-200 rounded-lg">
              <p className="font-semibold text-blue-700">Infrastructure</p>
              <ul className="mt-2 space-y-2 text-sm">
                <li>• Install additional traffic signals at Peelamedu</li>
                <li>• Improve street lighting in high-risk areas</li>
                <li>• Add pedestrian crossings near schools</li>
              </ul>
            </div>
            <div className="p-4 border border-green-200 rounded-lg">
              <p className="font-semibold text-green-700">Enforcement</p>
              <ul className="mt-2 space-y-2 text-sm">
                <li>• Increase patrols during peak hours</li>
                <li>• Deploy speed cameras at accident hotspots</li>
                <li>• Conduct regular safety audits</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

export default Analytics;