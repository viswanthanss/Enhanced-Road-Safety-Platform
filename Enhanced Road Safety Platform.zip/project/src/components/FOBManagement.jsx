import { useState } from 'react';
import { Card, Title, BarChart, DonutChart } from '@tremor/react';
import { MapPinIcon, UserGroupIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';

const fobData = {
  utilization: [
    { time: '6 AM', pedestrians: 120, cyclists: 45, vehicles: 0 },
    { time: '9 AM', pedestrians: 350, cyclists: 80, vehicles: 0 },
    { time: '12 PM', pedestrians: 280, cyclists: 65, vehicles: 0 },
    { time: '3 PM', pedestrians: 310, cyclists: 70, vehicles: 0 },
    { time: '6 PM', pedestrians: 420, cyclists: 90, vehicles: 0 },
    { time: '9 PM', pedestrians: 180, cyclists: 40, vehicles: 0 },
  ],
  safety: {
    incidents: 3,
    maintenance: 98,
    lighting: 95,
    accessibility: 92
  },
  hotspots: [
    { id: 1, name: 'Gandhipuram', risk: 'high', incidents: 15 },
    { id: 2, name: 'RS Puram', risk: 'medium', incidents: 8 },
    { id: 3, name: 'Peelamedu', risk: 'high', incidents: 12 }
  ]
};

function FOBManagement() {
  const [selectedView, setSelectedView] = useState('overview');

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <div className="flex items-center space-x-3">
            <MapPinIcon className="h-6 w-6 text-blue-600" />
            <div>
              <Title>Active FOBs</Title>
              <p className="text-2xl font-semibold">24</p>
              <p className="text-sm text-green-600">+2 this month</p>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center space-x-3">
            <UserGroupIcon className="h-6 w-6 text-green-600" />
            <div>
              <Title>Daily Users</Title>
              <p className="text-2xl font-semibold">15,234</p>
              <p className="text-sm text-green-600">+12.3% vs last week</p>
            </div>
          </div>
        </Card>

        <Card>
          <div className="flex items-center space-x-3">
            <ShieldCheckIcon className="h-6 w-6 text-yellow-600" />
            <div>
              <Title>Safety Score</Title>
              <p className="text-2xl font-semibold">94%</p>
              <p className="text-sm text-green-600">+3.2% vs last month</p>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>FOB Utilization (Last 24 Hours)</Title>
          <BarChart
            className="mt-4 h-72"
            data={fobData.utilization}
            index="time"
            categories={['pedestrians', 'cyclists']}
            colors={['blue', 'green']}
          />
        </Card>

        <Card>
          <Title>Safety Metrics</Title>
          <DonutChart
            className="mt-4 h-72"
            data={[
              { name: 'Maintenance', value: fobData.safety.maintenance },
              { name: 'Lighting', value: fobData.safety.lighting },
              { name: 'Accessibility', value: fobData.safety.accessibility }
            ]}
            category="value"
            index="name"
            colors={['blue', 'green', 'yellow']}
          />
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>High-Risk Areas</Title>
          <div className="mt-4 space-y-3">
            {fobData.hotspots.map((hotspot) => (
              <div key={hotspot.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{hotspot.name}</p>
                  <p className="text-sm text-gray-600">{hotspot.incidents} incidents</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  hotspot.risk === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {hotspot.risk}
                </span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <Title>Improvement Recommendations</Title>
          <div className="mt-4 space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <p className="font-semibold">Infrastructure</p>
              <ul className="mt-2 space-y-2 text-sm">
                <li>• Install additional lighting at Gandhipuram FOB</li>
                <li>• Repair escalator at RS Puram FOB</li>
                <li>• Add CCTV cameras at Peelamedu FOB</li>
              </ul>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <p className="font-semibold">User Experience</p>
              <ul className="mt-2 space-y-2 text-sm">
                <li>• Add multilingual signage</li>
                <li>• Improve accessibility ramps</li>
                <li>• Install weather protection</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

export default FOBManagement;