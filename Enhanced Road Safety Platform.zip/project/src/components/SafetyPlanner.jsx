import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import { Card, Title, TextInput, Button, Badge } from '@tremor/react';
import { MapPinIcon, ClockIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';
import { useSafetyData } from '../contexts/SafetyDataContext';

const COIMBATORE_CENTER = [11.0168, 76.9558];

// Demo data for fallback
const DEMO_ROUTES = {
  routes: [
    {
      id: 1,
      path: [
        [11.0168, 76.9558],
        [11.0268, 76.9658],
        [11.0368, 76.9458]
      ],
      safetyScore: 95,
      duration: '15 mins',
      distance: '3.2 km',
      hazards: [
        'School zone at 8 AM',
        'Construction work ahead',
        'Heavy traffic during peak hours'
      ]
    }
  ]
};

function SafetyPlanner() {
  const [startPoint, setStartPoint] = useState('');
  const [endPoint, setEndPoint] = useState('');
  const [routes, setRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { state: safetyData } = useSafetyData();

  const handleRouteCalculation = async () => {
    if (!startPoint || !endPoint) {
      setError('Please enter both start and end points');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // In a real implementation, this would call the actual API
      // For demo, we'll use the demo data after a short delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setRoutes(DEMO_ROUTES.routes);
      setSelectedRoute(DEMO_ROUTES.routes[0]);
      setError(null);
    } catch (err) {
      setError('Failed to calculate route. Please try again.');
      console.error('Route calculation error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Clear error when inputs change
  useEffect(() => {
    setError(null);
  }, [startPoint, endPoint]);

  return (
    <div className="space-y-6">
      <Card>
        <Title>Plan Your Safe Route</Title>
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <TextInput
              placeholder="Enter starting point"
              value={startPoint}
              onChange={(e) => setStartPoint(e.target.value)}
              className="input-clean"
              icon={MapPinIcon}
            />
            <TextInput
              placeholder="Enter destination"
              value={endPoint}
              onChange={(e) => setEndPoint(e.target.value)}
              className="input-clean"
              icon={MapPinIcon}
            />
          </div>
          
          <Button
            onClick={handleRouteCalculation}
            loading={loading}
            className="w-full md:w-auto btn btn-primary"
          >
            Calculate Safest Route
          </Button>

          {error && (
            <div className="p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              {error}
            </div>
          )}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <div className="h-[500px] rounded-lg overflow-hidden">
              <MapContainer
                center={COIMBATORE_CENTER}
                zoom={13}
                className="h-full w-full"
              >
                <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                {selectedRoute && (
                  <>
                    <Polyline
                      positions={selectedRoute.path}
                      color="#2563eb"
                      weight={4}
                    />
                    <Marker position={selectedRoute.path[0]}>
                      <Popup>Start Point</Popup>
                    </Marker>
                    <Marker position={selectedRoute.path[selectedRoute.path.length - 1]}>
                      <Popup>Destination</Popup>
                    </Marker>
                  </>
                )}
              </MapContainer>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          {selectedRoute && (
            <Card>
              <Title>Route Details</Title>
              <div className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <ShieldCheckIcon className="h-5 w-5 text-green-500" />
                    <span>Safety Score</span>
                  </div>
                  <Badge color="green">{selectedRoute.safetyScore}%</Badge>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <ClockIcon className="h-5 w-5 text-blue-500" />
                    <span>Estimated Time</span>
                  </div>
                  <span>{selectedRoute.duration}</span>
                </div>

                <div className="p-3 bg-yellow-50 rounded-lg">
                  <h4 className="font-semibold text-yellow-800">Alerts</h4>
                  <ul className="mt-2 space-y-2">
                    {selectedRoute.hazards.map((hazard, index) => (
                      <li key={index} className="text-sm text-yellow-700">
                        • {hazard}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Safety Tips</h4>
                  <ul className="mt-2 space-y-2">
                    <li className="text-sm text-blue-700">• Use FOB at major crossings</li>
                    <li className="text-sm text-blue-700">• Follow traffic signals</li>
                    <li className="text-sm text-blue-700">• Stay alert in construction zones</li>
                  </ul>
                </div>
              </div>
            </Card>
          )}

          <Card>
            <Title>Weather Conditions</Title>
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Temperature</p>
                <p className="text-xl font-semibold">28°C</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Visibility</p>
                <p className="text-xl font-semibold">Good</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default SafetyPlanner;