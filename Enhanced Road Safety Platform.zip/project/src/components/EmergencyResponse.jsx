import { useState } from 'react';
import { Card, Title, Button } from '@tremor/react';
import { PhoneIcon, MapPinIcon, BellAlertIcon } from '@heroicons/react/24/outline';

const EMERGENCY_CONTACTS = [
  { id: 1, name: 'Police Control Room', number: '100', type: 'police' },
  { id: 2, name: 'Ambulance', number: '108', type: 'medical' },
  { id: 3, name: 'Fire Service', number: '101', type: 'fire' },
  { id: 4, name: 'Traffic Control', number: '103', type: 'traffic' }
];

const NEARBY_FACILITIES = [
  {
    id: 1,
    name: 'Coimbatore Medical College Hospital',
    distance: '2.3 km',
    type: 'hospital',
    status: 'Available'
  },
  {
    id: 2,
    name: 'Race Course Police Station',
    distance: '1.5 km',
    type: 'police',
    status: 'Available'
  },
  {
    id: 3,
    name: 'Central Fire Station',
    distance: '3.1 km',
    type: 'fire',
    status: 'Available'
  }
];

function EmergencyResponse() {
  const [location, setLocation] = useState(null);
  const [locationError, setLocationError] = useState(null);

  const handleEmergencyCall = (number) => {
    window.location.href = `tel:${number}`;
  };

  const handleLocationShare = () => {
    setLocationError(null);
    
    if (!navigator.geolocation) {
      setLocationError('Geolocation is not supported by your browser');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude
        });
      },
      (error) => {
        let errorMessage = 'Unable to retrieve your location';
        
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Please enable location services to use this feature';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information is unavailable';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location request timed out';
            break;
          default:
            errorMessage = 'An unknown error occurred';
        }
        
        setLocationError(errorMessage);
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
      }
    );
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>Emergency Contacts</Title>
          <div className="mt-4 space-y-4">
            {EMERGENCY_CONTACTS.map((contact) => (
              <div
                key={contact.id}
                className="p-4 bg-white rounded-lg shadow-sm border border-gray-200 hover:border-blue-500 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <PhoneIcon className="h-6 w-6 text-blue-600" />
                    <div>
                      <p className="font-semibold">{contact.name}</p>
                      <p className="text-sm text-gray-600">{contact.number}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    color="red"
                    onClick={() => handleEmergencyCall(contact.number)}
                  >
                    Call Now
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <Title>Nearby Emergency Facilities</Title>
          <div className="mt-4 space-y-4">
            {NEARBY_FACILITIES.map((facility) => (
              <div
                key={facility.id}
                className="p-4 bg-white rounded-lg shadow-sm border border-gray-200"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <MapPinIcon className="h-6 w-6 text-green-600" />
                    <div>
                      <p className="font-semibold">{facility.name}</p>
                      <p className="text-sm text-gray-600">
                        {facility.distance} • {facility.status}
                      </p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => {/* Navigate to facility */}}
                  >
                    Get Directions
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <Title>Quick Actions</Title>
        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            size="lg"
            color="red"
            icon={BellAlertIcon}
            className="w-full"
            onClick={() => handleEmergencyCall('112')}
          >
            SOS Emergency
          </Button>
          <Button
            size="lg"
            variant="secondary"
            icon={MapPinIcon}
            className="w-full"
            onClick={handleLocationShare}
          >
            Share Location
          </Button>
          <Button
            size="lg"
            variant="secondary"
            icon={PhoneIcon}
            className="w-full"
            onClick={() => {/* Open contacts */}}
          >
            Emergency Contacts
          </Button>
          {locationError && (
            <div className="col-span-full p-3 bg-red-50 text-red-700 rounded-lg text-sm">
              {locationError}
            </div>
          )}
          {location && (
            <div className="col-span-full p-3 bg-green-50 text-green-700 rounded-lg text-sm">
              Location shared successfully
            </div>
          )}
        </div>
      </Card>

      <Card>
        <Title>Emergency Instructions</Title>
        <div className="mt-4 space-y-4">
          <div className="p-4 bg-red-50 rounded-lg">
            <p className="font-semibold text-red-700">In Case of Emergency:</p>
            <ul className="mt-2 space-y-2 text-sm text-red-600">
              <li>1. Stay calm and assess the situation</li>
              <li>2. Call emergency services immediately</li>
              <li>3. Share your exact location</li>
              <li>4. Follow dispatcher instructions</li>
              <li>5. Keep your emergency contacts informed</li>
            </ul>
          </div>
          <div className="p-4 bg-yellow-50 rounded-lg">
            <p className="font-semibold text-yellow-700">Important Notes:</p>
            <ul className="mt-2 space-y-2 text-sm text-yellow-600">
              <li>• Keep emergency numbers saved on your phone</li>
              <li>• Learn basic first aid techniques</li>
              <li>• Know your blood type and allergies</li>
              <li>• Keep emergency contacts updated</li>
            </ul>
          </div>
        </div>
      </Card>
    </div>
  );
}

export default EmergencyResponse;