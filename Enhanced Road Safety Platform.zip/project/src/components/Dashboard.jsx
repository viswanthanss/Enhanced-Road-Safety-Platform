import { useState } from 'react';
import { Card, Title, BarChart, DonutChart } from '@tremor/react';
import { 
  MapPinIcon, 
  UserGroupIcon, 
  ShieldCheckIcon,
  BellAlertIcon
} from '@heroicons/react/24/outline';

const fobData = {
  utilization: [
    { time: '6 AM', pedestrians: 120, cyclists: 45, vehicles: 0 },
    { time: '9 AM', pedestrians: 350, cyclists: 80, vehicles: 0 },
    { time: '12 PM', pedestrians: 280, cyclists: 65, vehicles: 0 },
    { time: '3 PM', pedestrians: 310, cyclists: 70, vehicles: 0 },
    { time: '6 PM', pedestrians: 420, cyclists: 90, vehicles: 0 },
    { time: '9 PM', pedestrians: 180, cyclists: 40, vehicles: 0 },
  ],
  safety: {
    incidents: 3,
    maintenance: 98,
    lighting: 95,
    accessibility: 92
  },
  hotspots: [
    { id: 1, name: 'Gandhipuram', risk: 'high', incidents: 15 },
    { id: 2, name: 'RS Puram', risk: 'medium', incidents: 8 },
    { id: 3, name: 'Peelamedu', risk: 'high', incidents: 12 }
  ]
};

const weatherData = {
  temperature: 28,
  condition: 'Clear',
  visibility: 'Good',
  rainfall: 0
};

function Dashboard() {
  const [selectedView, setSelectedView] = useState('overview');

  const stats = [
    {
      name: 'Active FOBs',
      value: '24',
      icon: MapPinIcon,
      change: '+2 this month',
      changeType: 'positive'
    },
    {
      name: 'Daily Users',
      value: '15,234',
      icon: UserGroupIcon,
      change: '+12.3% vs last week',
      changeType: 'positive'
    },
    {
      name: 'Safety Score',
      value: '94%',
      icon: ShieldCheckIcon,
      change: '+3.2% vs last month',
      changeType: 'positive'
    },
    {
      name: 'Active Alerts',
      value: '3',
      icon: BellAlertIcon,
      change: '-2 from yesterday',
      changeType: 'positive'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.name} className="space-y-3">
            <div className="flex items-center space-x-3">
              <stat.icon className="h-6 w-6 text-blue-600" />
              <Title>{stat.name}</Title>
            </div>
            <div className="space-y-1">
              <p className="text-2xl font-semibold">{stat.value}</p>
              <p className={`text-sm ${
                stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'
              }`}>
                {stat.change}
              </p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <Title>FOB Utilization (Last 24 Hours)</Title>
          <BarChart
            className="mt-4 h-72"
            data={fobData.utilization}
            index="time"
            categories={['pedestrians', 'cyclists']}
            colors={['blue', 'green']}
          />
        </Card>

        <Card>
          <Title>Safety Metrics</Title>
          <DonutChart
            className="mt-4 h-72"
            data={[
              { name: 'Maintenance', value: fobData.safety.maintenance },
              { name: 'Lighting', value: fobData.safety.lighting },
              { name: 'Accessibility', value: fobData.safety.accessibility }
            ]}
            category="value"
            index="name"
            colors={['blue', 'green', 'yellow']}
          />
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card>
          <Title>High-Risk Areas</Title>
          <div className="mt-4 space-y-3">
            {fobData.hotspots.map((hotspot) => (
              <div key={hotspot.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium">{hotspot.name}</p>
                  <p className="text-sm text-gray-600">{hotspot.incidents} incidents</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  hotspot.risk === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {hotspot.risk}
                </span>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <Title>Weather Conditions</Title>
          <div className="mt-4 space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Temperature</p>
                <p className="text-xl font-semibold">{weatherData.temperature}°C</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Condition</p>
                <p className="text-xl font-semibold">{weatherData.condition}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Visibility</p>
                <p className="text-xl font-semibold">{weatherData.visibility}</p>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">Rainfall</p>
                <p className="text-xl font-semibold">{weatherData.rainfall} mm</p>
              </div>
            </div>
          </div>
        </Card>

        <Card>
          <Title>Quick Actions</Title>
          <div className="mt-4 space-y-3">
            <button className="w-full p-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Report Incident
            </button>
            <button className="w-full p-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
              View Live Cameras
            </button>
            <button className="w-full p-3 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
              Emergency Contact
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

export default Dashboard;