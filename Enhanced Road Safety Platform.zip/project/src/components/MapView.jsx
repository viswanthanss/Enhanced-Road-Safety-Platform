import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import { Card, Title, Button } from '@tremor/react';
import 'leaflet/dist/leaflet.css';

const COIMBATORE_CENTER = [11.0168, 76.9558];
const ACCIDENT_DATA = [
  { id: 1, location: [11.0168, 76.9558], risk: 'high', incidents: 12 },
  { id: 2, location: [11.0268, 76.9658], risk: 'medium', incidents: 8 },
  { id: 3, location: [11.0368, 76.9458], risk: 'low', incidents: 3 }
];

const DATA_SOURCES = [
  { name: 'Historical Accident Data', source: 'Coimbatore Traffic Police (2020-2024)' },
  { name: 'Traffic Patterns', source: 'IoT Sensors and CCTV Analysis' },
  { name: 'Weather Data', source: 'Indian Meteorological Department' },
  { name: 'Road Conditions', source: 'Municipal Corporation of Coimbatore' }
];

function MapView() {
  const [mapType, setMapType] = useState('streets');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 1000);
  }, []);

  const getRiskColor = (risk) => {
    switch (risk) {
      case 'high': return '#ef4444';
      case 'medium': return '#f59e0b';
      case 'low': return '#10b981';
      default: return '#6b7280';
    }
  };

  if (loading) {
    return (
      <div className="animate-pulse">
        <div className="h-[600px] bg-gray-200 rounded-lg"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800">Accident Hotspot Map</h2>
        <div className="flex gap-2">
          <Button
            size="sm"
            onClick={() => setMapType('streets')}
            color={mapType === 'streets' ? 'blue' : 'gray'}
          >
            Streets
          </Button>
          <Button
            size="sm"
            onClick={() => setMapType('satellite')}
            color={mapType === 'satellite' ? 'blue' : 'gray'}
          >
            Satellite
          </Button>
        </div>
      </div>

      <div className="h-[600px] rounded-lg overflow-hidden shadow-lg">
        <MapContainer
          center={COIMBATORE_CENTER}
          zoom={13}
          style={{ height: '100%', width: '100%' }}
        >
          <TileLayer
            url={
              mapType === 'streets'
                ? 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
                : 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
            }
          />
          {ACCIDENT_DATA.map((point) => (
            <CircleMarker
              key={point.id}
              center={point.location}
              radius={20}
              pathOptions={{
                fillColor: getRiskColor(point.risk),
                color: getRiskColor(point.risk),
                fillOpacity: 0.7
              }}
            >
              <Popup>
                <div className="p-2">
                  <h3 className="font-bold text-lg capitalize">
                    {point.risk} Risk Zone
                  </h3>
                  <p>Incidents: {point.incidents}</p>
                  <p>Last updated: {new Date().toLocaleDateString()}</p>
                </div>
              </Popup>
            </CircleMarker>
          ))}
        </MapContainer>
      </div>

      <Card>
        <Title>Data Sources</Title>
        <div className="mt-4">
          <ul className="space-y-2">
            {DATA_SOURCES.map((source, index) => (
              <li key={index} className="flex items-start space-x-2">
                <span className="text-blue-500">•</span>
                <div>
                  <span className="font-medium">{source.name}: </span>
                  <span className="text-gray-600">{source.source}</span>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </Card>
    </div>
  );
}

export default MapView;