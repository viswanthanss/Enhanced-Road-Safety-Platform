import { useState, useEffect, useRef } from 'react';
import { Card, Title, AreaChart } from '@tremor/react';
import * as tf from '@tensorflow/tfjs';
import '@tensorflow/tfjs-backend-webgl';

function DriverMonitoring() {
  const videoRef = useRef(null);
  const [model, setModel] = useState(null);
  const [emotions, setEmotions] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadModel = async () => {
      try {
        const loadedModel = await tf.loadLayersModel('/models/emotion_detection_model.json');
        setModel(loadedModel);
      } catch (err) {
        setError('Failed to load emotion detection model');
        console.error(err);
      }
    };

    loadModel();
  }, []);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        setError('Failed to access camera');
        console.error(err);
      }
    };

    startCamera();
    return () => {
      if (videoRef.current?.srcObject) {
        videoRef.current.srcObject.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const processFrame = async () => {
    if (!model || !videoRef.current || isProcessing) return;

    setIsProcessing(true);
    try {
      const videoFrame = tf.browser.fromPixels(videoRef.current);
      const resized = tf.image.resizeBilinear(videoFrame, [48, 48]);
      const normalized = resized.div(255.0);
      const batched = normalized.expandDims(0);
      
      const predictions = await model.predict(batched).data();
      const emotion = getEmotionFromPredictions(predictions);
      
      setEmotions(prev => [...prev.slice(-29), emotion]);
      
      videoFrame.dispose();
      resized.dispose();
      normalized.dispose();
      batched.dispose();
    } catch (err) {
      console.error('Frame processing error:', err);
    }
    setIsProcessing(false);
  };

  useEffect(() => {
    const interval = setInterval(processFrame, 1000);
    return () => clearInterval(interval);
  }, [model, isProcessing]);

  return (
    <div className="space-y-6">
      <Card>
        <Title>Driver Monitoring System</Title>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-4">
          <div className="relative">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full rounded-lg shadow-lg"
            />
            {error && (
              <div className="absolute inset-0 flex items-center justify-center bg-red-50 rounded-lg">
                <p className="text-red-600">{error}</p>
              </div>
            )}
          </div>
          <div>
            <Card>
              <Title>Emotion Analysis</Title>
              <AreaChart
                className="h-72 mt-4"
                data={emotions.map((emotion, i) => ({
                  time: i,
                  ...emotion
                }))}
                index="time"
                categories={['attention', 'fatigue', 'distraction']}
                colors={['green', 'yellow', 'red']}
              />
            </Card>
          </div>
        </div>
      </Card>
    </div>
  );
}

export default DriverMonitoring;