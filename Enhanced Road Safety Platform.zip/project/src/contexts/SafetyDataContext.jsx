import { createContext, useContext, useReducer, useEffect } from 'react';
import { useWebSocket } from './WebSocketContext';

const SafetyDataContext = createContext(null);

const initialState = {
  hazards: [],
  routes: [],
  trafficData: [],
  loading: true,
  error: null
};

function safetyReducer(state, action) {
  switch (action.type) {
    case 'SET_HAZARDS':
      return { ...state, hazards: action.payload };
    case 'ADD_HAZARD':
      return { ...state, hazards: [...state.hazards, action.payload] };
    case 'UPDATE_ROUTES':
      return { ...state, routes: action.payload };
    case 'UPDATE_TRAFFIC':
      return { ...state, trafficData: action.payload };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    default:
      return state;
  }
}

export function SafetyDataProvider({ children }) {
  const [state, dispatch] = useReducer(safetyReducer, initialState);
  const { socket } = useWebSocket();

  useEffect(() => {
    if (!socket) return;

    socket.on('hazard-update', (hazard) => {
      dispatch({ type: 'ADD_HAZARD', payload: hazard });
    });

    socket.on('traffic-update', (data) => {
      dispatch({ type: 'UPDATE_TRAFFIC', payload: data });
    });

    // Initial data load
    const loadInitialData = async () => {
      try {
        const [hazards, traffic] = await Promise.all([
          fetch('/api/hazards').then(res => res.json()),
          fetch('/api/traffic').then(res => res.json())
        ]);

        dispatch({ type: 'SET_HAZARDS', payload: hazards });
        dispatch({ type: 'UPDATE_TRAFFIC', payload: traffic });
        dispatch({ type: 'SET_LOADING', payload: false });
      } catch (error) {
        dispatch({ type: 'SET_ERROR', payload: error.message });
        dispatch({ type: 'SET_LOADING', payload: false });
      }
    };

    loadInitialData();

    return () => {
      socket.off('hazard-update');
      socket.off('traffic-update');
    };
  }, [socket]);

  return (
    <SafetyDataContext.Provider value={{ state, dispatch }}>
      {children}
    </SafetyDataContext.Provider>
  );
}

export function useSafetyData() {
  const context = useContext(SafetyDataContext);
  if (!context) {
    throw new Error('useSafetyData must be used within a SafetyDataProvider');
  }
  return context;
}