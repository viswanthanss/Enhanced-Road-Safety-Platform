import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useState, useEffect, Suspense } from 'react';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import MapView from './components/MapView';
import Reports from './components/Reports';
import Analytics from './components/Analytics';
import EmergencyResponse from './components/EmergencyResponse';
import SafetyPlanner from './components/SafetyPlanner';
import FOBManagement from './components/FOBManagement';
import DriverMonitoring from './components/DriverMonitoring';
import SmartParking from './components/SmartParking';
import MobileNav from './components/MobileNav';
import LoadingScreen from './components/LoadingScreen';
import ErrorBoundary from './components/ErrorBoundary';
import { WebSocketProvider } from './contexts/WebSocketContext';
import { AuthProvider } from './contexts/AuthContext';
import { SafetyDataProvider } from './contexts/SafetyDataContext';

function App() {
  const [loading, setLoading] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener('resize', handleResize);

    // Initialize app data and APIs
    const initializeApp = async () => {
      try {
        await Promise.all([
          import('./services/mapService'),
          import('./services/safetyService'),
          import('./services/driverService'),
          import('./services/parkingService')
        ]);
        setLoading(false);
      } catch (error) {
        console.error('Failed to initialize app:', error);
      }
    };

    initializeApp();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <ErrorBoundary>
      <AuthProvider>
        <WebSocketProvider>
          <SafetyDataProvider>
            <Router>
              <div className="min-h-screen bg-gray-50">
                <Navbar isMobile={isMobile} />
                <main className="container mx-auto px-4 py-8 pb-20 mt-16">
                  <Suspense fallback={<LoadingScreen />}>
                    <Routes>
                      <Route path="/" element={<Dashboard />} />
                      <Route path="/map" element={<MapView />} />
                      <Route path="/reports" element={<Reports />} />
                      <Route path="/analytics" element={<Analytics />} />
                      <Route path="/emergency" element={<EmergencyResponse />} />
                      <Route path="/planner" element={<SafetyPlanner />} />
                      <Route path="/fob" element={<FOBManagement />} />
                      <Route path="/driver" element={<DriverMonitoring />} />
                      <Route path="/parking" element={<SmartParking />} />
                    </Routes>
                  </Suspense>
                </main>
                {isMobile && <MobileNav />}
              </div>
            </Router>
          </SafetyDataProvider>
        </WebSocketProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;