export const trafficData = [
  { time: '6 AM - 9 AM', volume: 'High', risk: 'Medium' },
  { time: '9 AM - 12 PM', volume: 'Medium', risk: 'Low' },
  { time: '12 PM - 3 PM', volume: 'Low', risk: 'Low' },
  { time: '3 PM - 6 PM', volume: 'High', risk: 'High' },
  { time: '6 PM - 9 PM', volume: 'Medium', risk: 'Medium' }
];