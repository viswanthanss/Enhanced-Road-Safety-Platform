export const accidentData = [
  { date: '2024-01', accidents: 45, injuries: 32, fatalities: 2 },
  { date: '2024-02', accidents: 38, injuries: 28, fatalities: 1 },
  { date: '2024-03', accidents: 42, injuries: 30, fatalities: 2 }
];