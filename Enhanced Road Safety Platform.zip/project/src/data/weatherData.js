export const weatherData = {
  temperature: 28,
  condition: 'Clear',
  visibility: 'Good',
  rainfall: 0
};